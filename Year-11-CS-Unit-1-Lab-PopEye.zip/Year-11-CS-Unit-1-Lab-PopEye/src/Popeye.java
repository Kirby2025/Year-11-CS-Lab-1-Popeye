import java.util.Scanner;

public class Popeye {
  public static void main(String[] args) {

    // Creating Scanner Object
    Scanner sc = new Scanner(System.in);

    // Prompting User for Input
    System.out.println("Enter the distance to travel in nautical miles: ");
    double nauticalMiles = sc.nextDouble();
    System.out.println("Enter the top speed of the boat in knots: ");
    double topSpeed = sc.nextDouble();
    System.out.println("Enter the average speed of the boat in knots: ");
    double averageSpeed = sc.nextDouble();

    // Setting Variables
    double nauticalToRegularMilesRatio = 1.1508; // Ratio of Nautical Miles to Regular Miles

    // Converting Nautical Miles to Regular Miles
    double regularMiles = nauticalMiles * nauticalToRegularMilesRatio;
    System.out.println("The distance to travel in regular miles is: " + regularMiles + " miles");

    // Calculating Travel Time at Top Speed
    double topSpeedTravelTime = nauticalMiles / topSpeed;
    System.out.println("The best case travel time is: " + topSpeedTravelTime + " hours at " + topSpeed + " knots");

    // Calculating Travel Time at Average Speed
    double averageSpeedTravelTime = nauticalMiles / averageSpeed;
    System.out.println("The average case travel time is: " + averageSpeedTravelTime + " hours at " + averageSpeed + " knots");
  }
} 